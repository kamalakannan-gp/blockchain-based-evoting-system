from django.urls import path

from . import views
from django.contrib.auth.forms import UserCreationForm


urlpatterns = [
    path('signup/', views.SignUp.as_view(), name='signup'),
  
    
]
